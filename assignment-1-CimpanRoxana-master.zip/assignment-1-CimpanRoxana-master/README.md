### Grading
Area           | Grade (0-10)
-------------- | ------------
Implementation |
Design         |
Documentation  |
Total          |
